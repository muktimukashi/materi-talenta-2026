import pygame
import random
import os


# =========================================================
# KONFIGURASI DASAR
# =========================================================

pygame.init()

LEBAR = 800
TINGGI = 500
FPS = 60

layar = pygame.display.set_mode((LEBAR, TINGGI))
pygame.display.set_caption("Python Collector")

jam = pygame.time.Clock()


# =========================================================
# WARNA
# =========================================================

PUTIH = (245, 245, 245)
HITAM = (25, 25, 35)
BIRU = (70, 130, 255)
BIRU_GELAP = (30, 40, 70)
KUNING = (255, 210, 40)
MERAH = (220, 70, 70)
HIJAU = (50, 190, 100)
ABU_ABU = (130, 135, 150)


# =========================================================
# FONT
# =========================================================

font_besar = pygame.font.Font(None, 64)
font_sedang = pygame.font.Font(None, 38)
font_kecil = pygame.font.Font(None, 28)


# =========================================================
# FILE HIGH SCORE
# =========================================================

FILE_HIGH_SCORE = "high_score.txt"


def baca_high_score():
    """
    Membaca high score dari file.
    Jika file belum ada, nilai awal adalah 0.
    """

    if not os.path.exists(FILE_HIGH_SCORE):
        return 0

    try:
        with open(FILE_HIGH_SCORE, "r", encoding="utf-8") as file:
            isi = file.read().strip()

            if isi == "":
                return 0

            return int(isi)

    except (OSError, ValueError):
        return 0


def simpan_high_score(skor):
    """
    Menyimpan skor jika lebih besar
    dari high score sebelumnya.
    """

    high_score = baca_high_score()

    if skor > high_score:
        try:
            with open(FILE_HIGH_SCORE, "w", encoding="utf-8") as file:
                file.write(str(skor))

        except OSError:
            print("High score gagal disimpan.")


# =========================================================
# FUNGSI TEKS
# =========================================================

def tampilkan_teks(
    teks,
    font,
    warna,
    x,
    y,
    posisi="kiri"
):
    gambar_teks = font.render(teks, True, warna)
    rect = gambar_teks.get_rect()

    if posisi == "tengah":
        rect.center = (x, y)

    elif posisi == "kanan":
        rect.topright = (x, y)

    else:
        rect.topleft = (x, y)

    layar.blit(gambar_teks, rect)


# =========================================================
# CLASS PLAYER
# =========================================================

class Player:
    def __init__(self):
        self.rect = pygame.Rect(
            100,
            220,
            45,
            45
        )

        self.kecepatan = 5
        self.nyawa = 3
        self.skor = 0

    def gerak(self):
        tombol = pygame.key.get_pressed()

        if tombol[pygame.K_LEFT] or tombol[pygame.K_a]:
            self.rect.x -= self.kecepatan

        if tombol[pygame.K_RIGHT] or tombol[pygame.K_d]:
            self.rect.x += self.kecepatan

        if tombol[pygame.K_UP] or tombol[pygame.K_w]:
            self.rect.y -= self.kecepatan

        if tombol[pygame.K_DOWN] or tombol[pygame.K_s]:
            self.rect.y += self.kecepatan

        # Membatasi player agar tidak keluar layar
        if self.rect.left < 0:
            self.rect.left = 0

        if self.rect.right > LEBAR:
            self.rect.right = LEBAR

        if self.rect.top < 70:
            self.rect.top = 70

        if self.rect.bottom > TINGGI:
            self.rect.bottom = TINGGI

    def gambar(self):
        pygame.draw.rect(
            layar,
            BIRU,
            self.rect,
            border_radius=8
        )

        # Mata kiri
        pygame.draw.circle(
            layar,
            PUTIH,
            (
                self.rect.x + 13,
                self.rect.y + 15
            ),
            5
        )

        # Mata kanan
        pygame.draw.circle(
            layar,
            PUTIH,
            (
                self.rect.x + 32,
                self.rect.y + 15
            ),
            5
        )

        # Mulut
        pygame.draw.line(
            layar,
            PUTIH,
            (
                self.rect.x + 13,
                self.rect.y + 32
            ),
            (
                self.rect.x + 32,
                self.rect.y + 32
            ),
            3
        )


# =========================================================
# CLASS COIN
# =========================================================

class Coin:
    def __init__(self):
        self.radius = 14
        self.pindah_posisi()

    def pindah_posisi(self):
        self.x = random.randint(
            self.radius,
            LEBAR - self.radius
        )

        self.y = random.randint(
            90,
            TINGGI - self.radius
        )

        self.rect = pygame.Rect(
            self.x - self.radius,
            self.y - self.radius,
            self.radius * 2,
            self.radius * 2
        )

    def gambar(self):
        pygame.draw.circle(
            layar,
            KUNING,
            (self.x, self.y),
            self.radius
        )

        pygame.draw.circle(
            layar,
            PUTIH,
            (self.x, self.y),
            self.radius,
            2
        )


# =========================================================
# CLASS ENEMY
# =========================================================

class Enemy:
    def __init__(self):
        self.rect = pygame.Rect(
            random.randint(300, 700),
            random.randint(100, 430),
            45,
            45
        )

        self.kecepatan_x = random.choice([-3, 3])
        self.kecepatan_y = random.choice([-2, 2])

    def gerak(self):
        self.rect.x += self.kecepatan_x
        self.rect.y += self.kecepatan_y

        if self.rect.left <= 0:
            self.kecepatan_x *= -1

        if self.rect.right >= LEBAR:
            self.kecepatan_x *= -1

        if self.rect.top <= 70:
            self.kecepatan_y *= -1

        if self.rect.bottom >= TINGGI:
            self.kecepatan_y *= -1

    def gambar(self):
        pygame.draw.rect(
            layar,
            MERAH,
            self.rect,
            border_radius=8
        )

        # Mata musuh
        pygame.draw.circle(
            layar,
            PUTIH,
            (
                self.rect.x + 13,
                self.rect.y + 15
            ),
            5
        )

        pygame.draw.circle(
            layar,
            PUTIH,
            (
                self.rect.x + 32,
                self.rect.y + 15
            ),
            5
        )

        # Mulut musuh
        pygame.draw.line(
            layar,
            PUTIH,
            (
                self.rect.x + 13,
                self.rect.y + 34
            ),
            (
                self.rect.x + 32,
                self.rect.y + 28
            ),
            3
        )


# =========================================================
# LATAR BELAKANG
# =========================================================

def gambar_latar():
    layar.fill(BIRU_GELAP)

    # Membuat titik dekorasi
    for x in range(30, LEBAR, 70):
        for y in range(100, TINGGI, 70):
            pygame.draw.circle(
                layar,
                ABU_ABU,
                (x, y),
                2
            )


# =========================================================
# STATUS GAME
# =========================================================

def gambar_status(player, waktu):
    pygame.draw.rect(
        layar,
        HITAM,
        (0, 0, LEBAR, 70)
    )

    tampilkan_teks(
        f"Skor: {player.skor}",
        font_kecil,
        PUTIH,
        20,
        22
    )

    tampilkan_teks(
        f"Nyawa: {player.nyawa}",
        font_kecil,
        PUTIH,
        180,
        22
    )

    tampilkan_teks(
        f"Waktu: {waktu}",
        font_kecil,
        PUTIH,
        340,
        22
    )

    tampilkan_teks(
        "Ambil 10 koin!",
        font_kecil,
        KUNING,
        LEBAR - 20,
        22,
        posisi="kanan"
    )


# =========================================================
# MENU AWAL
# =========================================================

def menu_awal():
    high_score = baca_high_score()

    while True:
        jam.tick(FPS)

        gambar_latar()

        tampilkan_teks(
            "PYTHON COLLECTOR",
            font_besar,
            KUNING,
            LEBAR // 2,
            130,
            posisi="tengah"
        )

        tampilkan_teks(
            "Ambil koin dan hindari musuh",
            font_sedang,
            PUTIH,
            LEBAR // 2,
            205,
            posisi="tengah"
        )

        tampilkan_teks(
            f"High Score: {high_score}",
            font_kecil,
            HIJAU,
            LEBAR // 2,
            255,
            posisi="tengah"
        )

        tampilkan_teks(
            "Tekan ENTER untuk bermain",
            font_sedang,
            BIRU,
            LEBAR // 2,
            335,
            posisi="tengah"
        )

        tampilkan_teks(
            "Gunakan tombol panah atau WASD",
            font_kecil,
            PUTIH,
            LEBAR // 2,
            385,
            posisi="tengah"
        )

        tampilkan_teks(
            "Tekan ESC untuk keluar",
            font_kecil,
            ABU_ABU,
            LEBAR // 2,
            430,
            posisi="tengah"
        )

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    return True

                if event.key == pygame.K_ESCAPE:
                    return False

        pygame.display.update()


# =========================================================
# HALAMAN SELESAI
# =========================================================

def halaman_selesai(player, menang):
    simpan_high_score(player.skor)

    while True:
        jam.tick(FPS)

        gambar_latar()

        if menang:
            judul = "KAMU MENANG!"
            warna_judul = HIJAU

        else:
            judul = "GAME OVER"
            warna_judul = MERAH

        tampilkan_teks(
            judul,
            font_besar,
            warna_judul,
            LEBAR // 2,
            140,
            posisi="tengah"
        )

        tampilkan_teks(
            f"Skor akhir: {player.skor}",
            font_sedang,
            PUTIH,
            LEBAR // 2,
            235,
            posisi="tengah"
        )

        tampilkan_teks(
            f"High Score: {baca_high_score()}",
            font_kecil,
            KUNING,
            LEBAR // 2,
            285,
            posisi="tengah"
        )

        tampilkan_teks(
            "Tekan R untuk bermain lagi",
            font_sedang,
            BIRU,
            LEBAR // 2,
            360,
            posisi="tengah"
        )

        tampilkan_teks(
            "Tekan ESC untuk kembali",
            font_kecil,
            PUTIH,
            LEBAR // 2,
            415,
            posisi="tengah"
        )

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "keluar"

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    return "ulang"

                if event.key == pygame.K_ESCAPE:
                    return "menu"

        pygame.display.update()


# =========================================================
# GAME UTAMA
# =========================================================

def jalankan_game():
    player = Player()
    coin = Coin()

    musuh_list = [
        Enemy(),
        Enemy()
    ]

    waktu_game = 60
    waktu_mulai = pygame.time.get_ticks()

    kebal = False
    waktu_kebal = 0

    game_aktif = True

    while game_aktif:
        jam.tick(FPS)

        # Menghitung waktu permainan
        waktu_sekarang = pygame.time.get_ticks()

        waktu_berjalan = (
            waktu_sekarang - waktu_mulai
        ) // 1000

        waktu_sisa = waktu_game - waktu_berjalan

        if waktu_sisa < 0:
            waktu_sisa = 0

        # Event
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "keluar", player

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return "menu", player

        # Gerakkan player
        player.gerak()

        # Gerakkan musuh
        for musuh in musuh_list:
            musuh.gerak()

        # Collision player dan coin
        if player.rect.colliderect(coin.rect):
            player.skor += 1
            coin.pindah_posisi()

            # Tambah musuh setelah skor 5
            if player.skor == 5:
                musuh_list.append(
                    Enemy()
                )

        # Collision player dan musuh
        if not kebal:
            for musuh in musuh_list:
                if player.rect.colliderect(musuh.rect):
                    player.nyawa -= 1

                    kebal = True
                    waktu_kebal = waktu_sekarang

                    # Player kembali ke posisi awal
                    player.rect.x = 100
                    player.rect.y = 220

                    break

        # Kebal selama 1,5 detik
        if kebal:
            if waktu_sekarang - waktu_kebal > 1500:
                kebal = False

        # Kondisi menang
        if player.skor >= 10:
            return "menang", player

        # Kondisi kalah
        if player.nyawa <= 0:
            return "kalah", player

        if waktu_sisa <= 0:
            return "kalah", player

        # Menggambar
        gambar_latar()
        gambar_status(player, waktu_sisa)

        coin.gambar()

        for musuh in musuh_list:
            musuh.gambar()

        # Player berkedip ketika kebal
        if not kebal:
            player.gambar()
        else:
            if waktu_sekarang // 150 % 2 == 0:
                player.gambar()

        pygame.display.update()

    return "keluar", player


# =========================================================
# PROGRAM UTAMA
# =========================================================

def main():
    aplikasi_aktif = True

    while aplikasi_aktif:
        mulai = menu_awal()

        if not mulai:
            break

        bermain = True

        while bermain:
            hasil, player = jalankan_game()

            if hasil == "keluar":
                aplikasi_aktif = False
                bermain = False

            elif hasil == "menu":
                bermain = False

            elif hasil == "menang":
                pilihan = halaman_selesai(
                    player,
                    True
                )

                if pilihan == "ulang":
                    bermain = True

                elif pilihan == "menu":
                    bermain = False

                else:
                    aplikasi_aktif = False
                    bermain = False

            elif hasil == "kalah":
                pilihan = halaman_selesai(
                    player,
                    False
                )

                if pilihan == "ulang":
                    bermain = True

                elif pilihan == "menu":
                    bermain = False

                else:
                    aplikasi_aktif = False
                    bermain = False

    pygame.quit()


if __name__ == "__main__":
    main()